﻿Imports MPVB.ServiceReference

Module Module1

	Sub Main()

		Const username As String = "username"
		Const password As String = "password"
		Const from As String = "5000..."
		Const toNum As String = "09123456789"
		Const text As String = "تست وب سرویس ملی پیامک"
		Const isFlash As Boolean = False
		Dim soapClient As New SendSoapClient()
		Dim result = soapClient.SendSimpleSMS2(username, password, toNum, from, text, isFlash)

		'Dim restClient As New RestClient(username, password)
		'Dim result = restClient.Send(toNum, from, text, isFlash)

	End Sub

End Module
